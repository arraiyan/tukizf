function show_bar_item(){
    item =  document.getElementById('bars')

}