function show_bar_item(){
    item =  document.getElementById('sbar');
    if(item.style.display == 'none'){
        item.style.display = 'block';
    }else{item.style.display='none';}

}
function show_comment(){
    item = document.getElementById('comment')
    if(item.style.display == 'none'){
        item.style.display = 'block';
    }else{item.style.display='none';}
}
